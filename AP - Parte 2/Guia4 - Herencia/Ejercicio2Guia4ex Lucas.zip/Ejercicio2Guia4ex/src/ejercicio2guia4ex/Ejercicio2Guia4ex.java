/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2guia4ex;

/**
 *
 * @author Lucas
 */
public class Ejercicio2Guia4ex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Combustible combu = new Combustible ("Nasta", 500.99);
        Vehiculo vx = new Camion ("BMW","ABC123", combu);
        
        Viaje v1 = new Viaje ("San Luis", "Rufino",500,"Nasta", vx, 4, true, 100, 700);
        System.out.println("El costo total del viaje es: "+v1.costoTotal());
        System.out.println(v1.calcularDistancia());
       
    }
    
}
