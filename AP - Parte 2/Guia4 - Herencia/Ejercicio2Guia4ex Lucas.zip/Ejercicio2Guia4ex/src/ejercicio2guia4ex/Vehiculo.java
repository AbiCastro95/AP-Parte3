/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2guia4ex;

/**
 *
 * @author Lucas
 */
public abstract class Vehiculo {
    
    protected String marca;
    protected String patente;
    protected Combustible combustible;

    public Vehiculo() {
    }

    public Vehiculo(String marca, String patente, Combustible combustible) {
        this.marca = marca;
        this.patente = patente;
        this.combustible = combustible;
    }
    
    public abstract double calcularCombustible();
    
    public abstract double categoriaPeaje();
    
    
}
