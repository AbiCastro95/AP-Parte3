/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2guia4ex;

/**
 *
 * @author Lucas
 */
public class Viaje {

    private String lugarorigen;
    private String lugardestino;
    private double distanciaciudades;
    private String combustible;
    private Vehiculo vehiculo;
    private int peajes;
    private boolean ciudadmismaruta;
    private double kmorigen;
    private double kmdestino;

    public Viaje() {
    }

    public Viaje(String lugarorigen, String lugardestino, double distanciaciudades, String combustible, Vehiculo vehiculo, int peajes, boolean ciudadmismaruta, double kmorigen, double kmdestino) {
        this.lugarorigen = lugarorigen;
        this.lugardestino = lugardestino;
        this.distanciaciudades = distanciaciudades;
        this.combustible = combustible;
        this.vehiculo = vehiculo;
        this.peajes = peajes;
        this.ciudadmismaruta = ciudadmismaruta;
        this.kmorigen = kmorigen;
        this.kmdestino = kmdestino;
    }

    public String getLugarorigen() {
        return lugarorigen;
    }

    public void setLugarorigen(String lugarorigen) {
        this.lugarorigen = lugarorigen;
    }

    public String getLugardestino() {
        return lugardestino;
    }

    public void setLugardestino(String lugardestino) {
        this.lugardestino = lugardestino;
    }

    public double getDistanciaciudades() {
        return distanciaciudades;
    }

    public void setDistanciaciudades(double distanciaciudades) {
        this.distanciaciudades = distanciaciudades;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public int getPeajes() {
        return peajes;
    }

    public void setPeajes(int peajes) {
        this.peajes = peajes;
    }

    public boolean isCiudadmismaruta() {
        return ciudadmismaruta;
    }

    public void setCiudadmismaruta(boolean ciudadmismaruta) {
        this.ciudadmismaruta = ciudadmismaruta;
    }

    public double getKmorigen() {
        return kmorigen;
    }

    public void setKmorigen(double kmorigen) {
        this.kmorigen = kmorigen;
    }

    public double getKmdestino() {
        return kmdestino;
    }

    public void setKmdestino(double kmdestino) {
        this.kmdestino = kmdestino;
    }

    public double calcularDistancia() {
        if (ciudadmismaruta) {
            return this.kmdestino - this.kmorigen;

        } else {

            return this.distanciaciudades;
        }

    }

    public double costoPeaje() {
        double costo = 100;
        if (vehiculo.categoriaPeaje() == 1) {
            return costo * this.peajes;

        } else {
            return (costo * this.peajes) * 2;

        }

    }

    public double costoCombustible(double distanciaciudades) {
        
        return vehiculo.calcularCombustible()*distanciaciudades;
        

    }

    public double costoTotal() {
        
        return costoPeaje()+costoCombustible(calcularDistancia());

    }
}
