/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2guia4ex;

/**
 *
 * @author Lucas
 */
public class Auto extends Vehiculo {
    
    

    public Auto(String marca, String patente, Combustible combustible) {
        super(marca, patente, combustible);
    }
    

    @Override
    public double calcularCombustible() {
        double consumo= 7.0/100;
        return consumo * combustible.getPrecio();
        
        
        
        
    }

    @Override
    public double categoriaPeaje() {
        
        return 1;
        
        
    }

}
