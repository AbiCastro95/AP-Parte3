/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2guia4ex;

/**
 *
 * @author Lucas
 */
public class Combustible {
    
    private String combustible;
    private double precio;

    public Combustible() {
    }

    public Combustible(String combustible, double precio) {
        this.combustible = combustible;
        this.precio = precio;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}
