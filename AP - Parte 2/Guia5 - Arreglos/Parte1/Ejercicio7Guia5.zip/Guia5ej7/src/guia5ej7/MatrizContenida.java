
package guia5ej7;


public class MatrizContenida {
    private int[][]matrizM;
    private int[][]matrizP;

    public MatrizContenida(int[][] matrizM, int[][] matrizP) {
        this.matrizM = matrizM;
        this.matrizP = matrizP;
    }
    
    public boolean verificarMatrizContenida(){
        int filaM = matrizM.length;
        int columnaM = matrizM[0].length;
        int filaP = matrizP.length;
        int columnaP = matrizP[0].length;
        
        for (int i = 0; i <= filaM - filaP; i++) {
            for (int j = 0; j <= columnaM - columnaP; j++) {
                if (verificarSubmatriz(i,j)) {
                    System.out.println("La submatriz P se encuentra en la matriz M en los indices: ");
                    for (int x = i; x < i + filaP; x++) {
                        for (int y = j; y < j + columnaP; y++) {
                            System.out.print(x + "," + y + " ");
                        }
                    }
                    System.out.println();
                    return true;
                }
            }
        }
        System.out.println("La matriz P no esta contenida en la matriz M.");
        return false;
    }
    
    private boolean verificarSubmatriz(int inicioFila, int inicioColumna) {
        int filaP = matrizP.length;
        int columnaP = matrizP[0].length;
        
        for (int i = 0; i < filaP; i++){
            for (int j = 0; j < columnaP; j++) {
                if (matrizM[inicioFila + i][inicioColumna + j] != matrizP[i][j]) {
                    return false;
                }
            }
        }
        return true;
        
    }
    
    
}
